import React from 'react'
import BasicForm from './BasicForm'
import FormHook from './FormHook'

function Main() {
  return (
    <div>
        {/* <Form/><BasicForm/> */}
        <FormHook/>
    </div>
  )
}

export default Main