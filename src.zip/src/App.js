import './App.css';
import Main  from './Forms/Main';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div>
          <Main/>
          
    </div>
  );
}

export default App;
